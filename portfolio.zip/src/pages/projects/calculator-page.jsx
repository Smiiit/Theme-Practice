import { Helmet } from 'react-helmet-async';

import { CalculatorView } from 'src/sections/projects/calculator/calculator-view';

// ----------------------------------------------------------------------

const metadata = { title: `Smit | Projects ` };

export default function CalculatorPage() {
  return (
    <>
      <Helmet>
        <title> {metadata.title}</title>
      </Helmet>

      <CalculatorView />
    </>
  );
}

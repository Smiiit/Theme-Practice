import { RHFTextField } from './rhf-text-field';

// ----------------------------------------------------------------------

export const Field = {
  Text: RHFTextField,
};

export { default as SentIcon } from './sent-icon';

export { default as PasswordIcon } from './password-icon';

export { default as PlanFreeIcon } from './plan-free-icon';

export { default as EmailInboxIcon } from './email-inbox-icon';

export { default as PlanStarterIcon } from './plan-starter-icon';

export { default as PlanPremiumIcon } from './plan-premium-icon';

export { default as NewPasswordIcon } from './new-password-icon';

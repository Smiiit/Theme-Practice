import { paths } from 'src/routes/paths';

import { CONFIG } from 'src/config-global';

import { SvgColor } from 'src/components/svg-color';

// ----------------------------------------------------------------------

const icon = (name) => <SvgColor src={`${CONFIG.site.basePath}/assets/icons/navbar/${name}.svg`} />;

const ICONS = {
  job: icon('ic-job'),
  blog: icon('ic-blog'),
  chat: icon('ic-chat'),
  mail: icon('ic-mail'),
  user: icon('ic-user'),
  file: icon('ic-file'),
  lock: icon('ic-lock'),
  tour: icon('ic-tour'),
  order: icon('ic-order'),
  label: icon('ic-label'),
  blank: icon('ic-blank'),
  kanban: icon('ic-kanban'),
  folder: icon('ic-folder'),
  course: icon('ic-course'),
  banking: icon('ic-banking'),
  booking: icon('ic-booking'),
  invoice: icon('ic-invoice'),
  product: icon('ic-product'),
  calendar: icon('ic-calendar'),
  disabled: icon('ic-disabled'),
  external: icon('ic-external'),
  menuItem: icon('ic-menu-item'),
  ecommerce: icon('ic-ecommerce'),
  analytics: icon('ic-analytics'),
  dashboard: icon('ic-dashboard'),
  parameter: icon('ic-parameter'),
};

// ----------------------------------------------------------------------

export const navData = [
  {
    // subheader: 'Version 2.1.4',
    items: [{ title: 'Dashboard', path: paths.dashboard.root, icon: ICONS.dashboard }],
  },
  {
    items: [
      {
        title: 'Projects',
        path: paths.dashboard.projects.root,
        icon: ICONS.user,
        children: [
          { title: 'Calculator', path: paths.dashboard.projects.root },
          { title: 'QMS', path: paths.dashboard.projects.qms },
          // { title: 'Five', path: paths.dashboard.group.five },
        ],
      },
    ],
  },
  {
    items: [{ title: 'Contact', path: paths.dashboard.contact, icon: ICONS.dashboard }],
  },
];

// export const navData = [
//   /**
//    * Overview
//    */
//   {
//     subheader: 'Version 2.1.4',
//     items: [
//       { title: 'One', path: paths.dashboard.root, icon: ICONS.dashboard },
//       { title: 'Two', path: paths.dashboard.two, icon: ICONS.ecommerce },
//       { title: 'Three', path: paths.dashboard.three, icon: ICONS.analytics },
//     ],
//   },
//   /**
//    * Management
//    */
//   {
//     subheader: 'Management',
//     items: [
//       {
//         title: 'Group',
//         path: paths.dashboard.group.root,
//         icon: ICONS.user,
//         children: [
//           { title: 'Four', path: paths.dashboard.group.root },
//           { title: 'Five', path: paths.dashboard.group.five },
//           { title: 'Six', path: paths.dashboard.group.six },
//         ],
//       },
//     ],
//   },
// ];

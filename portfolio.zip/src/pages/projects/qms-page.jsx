import { Helmet } from 'react-helmet-async';

import { QMSView } from 'src/sections/projects/qms/qms-view';

// ----------------------------------------------------------------------

const metadata = { title: `Smit | Projects ` };

export default function QMSPage() {
  return (
    <>
      <Helmet>
        <title> {metadata.title}</title>
      </Helmet>

      <QMSView />
    </>
  );
}

import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';

import { CONFIG } from 'src/config-global';
import { DashboardLayout } from 'src/layouts/dashboard';

import { LoadingScreen } from 'src/components/loading-screen';

import { AuthGuard } from 'src/auth/guard';

// ----------------------------------------------------------------------

const Dashboard = lazy(() => import('src/pages/dashboard/dashboard-page'));
const Calculator = lazy(() => import('src/pages/projects/calculator-page'));
const QMS = lazy(() => import('src/pages/projects/qms-page'));
const Contact = lazy(() => import('src/pages/contact/contact-page'));

// ----------------------------------------------------------------------

const layoutContent = (
  <DashboardLayout>
    <Suspense fallback={<LoadingScreen />}>
      <Outlet />
    </Suspense>
  </DashboardLayout>
);

export const dashboardRoutes = [
  {
    path: 'dashboard',
    element: CONFIG.auth.skip ? <>{layoutContent}</> : <AuthGuard>{layoutContent}</AuthGuard>,
    children: [
      { element: <Dashboard />, index: true },
      {
        path: 'projects',
        children: [
          { element: <Calculator />, index: true },
          { path: 'qms', element: <QMS /> },
        ],
      },
      { path: 'contact', element: <Contact /> },
    ],
  },
];

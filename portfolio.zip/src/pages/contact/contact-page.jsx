import { Helmet } from 'react-helmet-async';
import { ContactView } from 'src/sections/contact/contact-view';

// ----------------------------------------------------------------------

const metadata = { title: `Smit | Dashbaord` };

export default function ContactPage() {
  return (
    <>
      <Helmet>
        <title> {metadata.title}</title>
      </Helmet>

      <ContactView />
    </>
  );
}

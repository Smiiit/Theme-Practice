import { Helmet } from 'react-helmet-async';

import { DashboardView } from 'src/sections/dashboard/dashboard-view';

// ----------------------------------------------------------------------

const metadata = { title: `Smit | Dashbaord` };

export default function DashboardPage() {
  return (
    <>
      <Helmet>
        <title> {metadata.title}</title>
      </Helmet>

      <DashboardView />
    </>
  );
}

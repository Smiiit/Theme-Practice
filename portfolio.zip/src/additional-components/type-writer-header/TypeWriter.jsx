import { TypeAnimation } from 'react-type-animation';

export default function TypeWriter() {
  return (
    <TypeAnimation
      sequence={[
        // Same substring at the start will only be typed out once, initially
        `Smit Panchal, a Web Developer`,
        1000, // wait 1s before replacing "Mice" with "Hamsters"
        'Smit Panchal, a Traniee Engineer',
        1000,
        // 'We produce food for Guinea Pigs',
        // 1000,
        // 'We produce food for Chinchillas',
        // 1000
      ]}
      wrapper="span"
      speed={50}
      style={{
        fontSize: '2em',
        display: 'inline-block',
        fontWeight: 'bold',
        fontFamily: 'monospace',
        // fontFamily: 'cursive',
      }}
      repeat={Infinity}
    />
  );
}
